import json
import boto3
from datetime import datetime, timedelta
import pytz
import pymsteams
import requests
from botocore.exceptions import ClientError
import os
import time

# MRIDULA BUILDING THE SCRIPT #

# create a boto3 health client
health_client = boto3.client('health')


def send_alert(event_details, event_type):
    """
    Takes as input the event_details and event_type. An alert is sent to notify the
    our AWS slack channels of new or resolved health events from the AWS health check.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param event_type: type of event - i.e. incident creation/resolution
    :type event_type: str
    """
    summary = ""
    message = ""

    if event_type == "create":
        summary+=(
            f"[NEW] AWS reported an issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {event_details['successfulSet'][0]['eventDescription']['latestDescription']}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    elif event_type == "resolve":
        summary+=(
            f"[RESOLVED] The AWS issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*End Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['endTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {get_last_AWS_update(event_details)}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are still experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    slack_url = get_secrets()["slack"]
    teams_url = get_secrets()["teams"]

    if slack_url != "None":
        send_to_slack(message, slack_url)
    if teams_url != "None":
        send_to_teams(message, teams_url)



def send_to_slack(message, webhookurl):
    slack_data = {'text': message}
    response = requests.post(
        webhookurl, data=json.dumps(slack_data),
        headers={'Content-Type': 'application/json'}
    )
    if response.status_code != 200:
        raise ValueError(
            'Request to slack returned an error %s, the response is:\n%s'
            % (response.status_code, response.text)
        )


def send_to_teams(message, webhookurl):
    # create the connectorcard object with the Microsoft Webhook URL
    myTeamsMessage = pymsteams.connectorcard(webhookurl)
    # Add title
    myTeamsMessage.title("AWS REPORTED ISSUE ALERT")
    # Add text to the message.
    myTeamsMessage.text(message)
    # send the message.
    myTeamsMessage.send()

def format_date(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')


def get_last_AWS_update(event_details):
    """
    Takes as input the event_details and returns the last update from AWS (instead of the entire timeline)

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :return: the last update message from AWS
    :rtype: str
    """
    aws_message = event_details['successfulSet'][0]['eventDescription']['latestDescription']
    aws_messages_list = aws_message.split("\n\n")
    aws_resolve_message = aws_messages_list[len(aws_messages_list) - 1]
    return aws_resolve_message


def cleanup_time_for_slack(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')


def get_secrets():
    secret_teams_name = "MicrosoftChannelID"
    secret_slacks_name = "SlackChannelID"
    secret_pd_name = "PagerDutyChannelID"
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response_teams = client.get_secret_value(
            SecretId=secret_teams_name
        )
        get_secret_value_response_slack = client.get_secret_value(
            SecretId=secret_slacks_name
        )
        get_secret_value_response_pd = client.get_secret_value(
            SecretId=secret_pd_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response_teams:
            teams_channel_id = get_secret_value_response_teams['SecretString']
            print("Teams secret is" + teams_channel_id)

        if 'SecretString' in get_secret_value_response_slack:
            slack_channel_id = get_secret_value_response_slack['SecretString']
            print("Slack secret is" + slack_channel_id)

        if 'SecretString' in get_secret_value_response_pd:
            pd_channel_id = get_secret_value_response_pd['SecretString']
            print("Pager Duty secret is" + pd_channel_id)
        secrets = {
            "teams": teams_channel_id,
            "slack": slack_channel_id,
            "pdchannel": pd_channel_id}
    return secrets

def describe_events():
    """
    Returns information about events that meet the specified filter criteria. Events are returned in a summary
    form and do not include the detailed description, any additional metadata that depends on the event type,
    or any affected resources.

    :return: dictionary of events
    :rtype: dict
    """
    dt_frequency_pst = (datetime.now() - timedelta(minutes=1)).astimezone(pytz.timezone('US/Pacific'))
    # Need to add this as a parameter to the CFN stack
    delimiter = "|"
    regionlist = os.environ['REGIONS_LIST']
    if delimiter in regionlist:
        regions = os.environ['REGIONS_LIST'].split("|")
    else:
        # Default covers for US regions
        regions = [
            'us-east-1',
            'us-east-2',
            'us-west-1',
            'us-west-2',
            'global'
        ]
    for aws_region in regions:
        print("User selected regions:" + aws_region)
    response = health_client.describe_events(
        filter={
            'regions': regions,
            'lastUpdatedTimes': [
                {
                    'from': dt_frequency_pst
                },
            ],
            'eventTypeCategories': [
                'issue'
            ]
        }
    )
    events = response.get('events', [])

    if 'nextToken' in response:
        next_token = response['nextToken']
        while next_token:
            response = health_client.describe_events(
                filter={
                    'regions': regions,
                    'lastUpdatedTimes': [
                        {
                            'from': dt_frequency_pst
                        },
                    ],
                    'eventTypeCategories': [
                        'issue'
                    ]
                },
                nextToken=next_token
            )
            # print(response)
            if response is not None:
                events.extend(response.get('events', []))

                try:
                    next_token = response['nextToken']
                except BaseException:
                    next_token = False
    return events


def myconverter(json_object):
    """
    The __str__ method of the datetime object is called to return a string representation of the value.

    :param json_object: json object
    :type json_object: dict
    :return: string representation of the json object
    :rtype: str
    """
    if isinstance(json_object, datetime):
        return json_object.__str__()


def main(event, context):
    print("THANK YOU FOR CHOOSING AWS HEALTH CHECK!")
    # Keep polling the HEALTH API
    print(event)
    if 'Records' not in event:
        aws_events = describe_events()
        # converting
        aws_events = json.dumps(aws_events, default=myconverter)
        # parsing
        aws_events = json.loads(aws_events)
    # FOR TESTING
    with open('aws-status.json') as json_file:
        aws_events = json.load(json_file)
        for event in aws_events:
            print(event);
    send_alert(aws_events, event_type="resolve")


if __name__ == "__main__":
    main('', '')



 f"--------------\n*{summary}*\n"
        f">*Event ARN:* {event_details[0]['arn']}\n"
        f">*Service:* {event_details[0]['service']}\n"
        f">*Region:* {event_details[0]['region']}\n"
        f">*Start Time:* {format_date(event_details[0]['startTime'])}\n"
        f">*Status:* {event_details[0]['statusCode']}\n"
        f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
        f"*If you are experiencing issues related to this event, please open an AWS Support case within your account.*\n"