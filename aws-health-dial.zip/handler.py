import json
import boto3
from datetime import datetime, timedelta
import pytz
import pymsteams
import requests
from botocore.exceptions import ClientError
import os
import time

# MRIDULA BUILDING THE SCRIPT #

# create a boto3 health client
health_client = boto3.client('health')

def send_to_slack(message, webhookurl):
    slack_data = {'text': message}
    response = requests.post(
        webhookurl, data=json.dumps(slack_data),
        headers={'Content-Type': 'application/json'}
    )
    if response.status_code != 200:
        raise ValueError(
            'Request to slack returned an error %s, the response is:\n%s'
            % (response.status_code, response.text)
        )
    else:
        print("Response sent to slack")


def send_to_teams(message, webhookurl):
    # create the connectorcard object with the Microsoft Webhook URL
    myTeamsMessage = pymsteams.connectorcard(webhookurl)
    # Add title
    myTeamsMessage.title("AWS REPORTED ISSUE ALERT")
    # Add text to the message.
    myTeamsMessage.text(message)
    # send the message.
    myTeamsMessage.send()

def send_email(event_details, eventType):
    SENDER = os.environ['FROM_EMAIL']
    RECIPIENT = os.environ['TO_EMAIL'].split(",")
    #RECIPIENT += os.environ['FROM_EMAIL']
    # RECIPIENT = "gmridula@amazon.com" #for testing
    AWS_REGION = "us-east-1"
    SUBJECT = os.environ['EMAIL_SUBJECT']


    if eventType == "create":
        BODY_HTML = f"""
            <html>
                <body>
                    <h>Hello Everyone!</h><br>
                    <p>There is an AWS incident that is in effect which may likely impact your resources. Here are the issue details:<br>
                    <b><br>
                    <b>Event ARN:</b> {event_details[0]['arn']}<br>
                    <b><br>
                    <b>AWS Service:</b> {event_details[0]['service']}<br>
                    <b><br>
                    <b>Region:</b> {event_details[0]['region']}<br>
                    <b><br>
                    <b>Status:</b> {event_details[0]['statusCode']}<br>
                    <b><br>
                    If you are impacted, please open an AWS Support case from the impacted account(s) and reply back to this email by describing the impact this is having on your environments.
                    <b><br>
                    You can monitor the AWS Service Health Dashboard for updates on this issue: https://status.aws.amazon.com/</a><br><br>
                    Thanks, <br>AWS TAM Team
                    </p>
                </body>
            </html>
        """
    else:
        BODY_HTML = f"""
                    <html>
                        <body>
                            <h>Hello Everyone!</h><br>
                            <p>UPDATE on the AWS incident:<br>
                            <b><br>
                            <b>Event ARN:</b> {event_details[0]['arn']}<br>
                            <b><br>
                            <b>AWS Service:</b> {event_details[0]['service']}<br>
                            <b><br>
                            <b>Region:</b> {event_details[0]['region']}<br>
                            <b><br>
                            <b>Status:</b> {event_details[0]['statusCode']}<br>
                            <b><br>
                            If you are impacted, please open an AWS Support case from the impacted account(s) and reply back to this email by describing the impact this is having on your environments.
                            <br><br>
                            Thanks, <br>AWS TAM Team
                            </p>
                        </body>
                    </html>
                """
    client = boto3.client('ses',region_name=AWS_REGION)
    response = client.send_email(
        Source=SENDER,
        Destination={
            'ToAddresses': RECIPIENT
        },
        Message={
            'Body': {
                'Html': {
                    'Data': BODY_HTML
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': SUBJECT,
            },
        },
    )
    print(response)


def create_message(event_details, event_type):
    summary = ""
    message = ""
    print("Entered create_message");
    if event_type == "create":
        summary+=(
            f"[NEW] AWS reported an issue with the {event_details[0]['service'].upper()} service in "
            f"the {event_details[0]['region'].upper()} region."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details[0]['arn']}\n"
            f">*AWS Service:* {event_details[0]['service']}\n"
            f">*Region:* {event_details[0]['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details[0]['startTime'])}\n"
            f">*Status:* {event_details[0]['statusCode']}\n"
            #f">*Message from AWS:* {event_details[0]['eventDescription']['latestDescription']}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    elif event_type == "resolve":
        summary+=(
            f"[RESOLVED] The AWS issue with the {event_details[0]['service'].upper()} service in "
            f"the {event_details[0]['region'].upper()} region is now resolved."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details[0]['arn']}\n"
            f">*AWS Service:* {event_details[0]['service']}\n"
            f">*Region:* {event_details[0]['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details[0]['startTime'])}\n"
            f">*End Time:* {cleanup_time_for_slack(event_details[0]['endTime'])}\n"
            f">*Status:* {event_details[0]['statusCode']}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are still experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )
    print("Message:" + message);
    return message

def send_test_alert(event_details):
    """
    Takes as input the event_details and event_type. An alert is sent to notify the
    our AWS slack channels of new or resolved health events from the AWS health check.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param event_type: type of event - i.e. incident creation/resolution
    :type event_type: str
    """
    if event_details[0]['statusCode'] == "open":
        event_type="create"
    else:
        event_type="resolve"

    #SLACK ALERT
    slack_url = get_secrets()["slack"]
    if slack_url != "None":
        message = create_message(event_details, event_type)
        send_to_slack(message, slack_url)

    #TEAMS_ALERT
    teams_url = get_secrets()["teams"]
    if teams_url != "None":
        send_to_teams(message, teams_url)

    #EMAIL ALERT
    if '.com' in str(os.environ['FROM_EMAIL']) and '.com' in str(os.environ['TO_EMAIL']):
        send_email(event_details, event_type)



def format_date(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')


def cleanup_time_for_slack(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')


def get_secrets():
    secret_teams_name = "MicrosoftChannelID"
    secret_slacks_name = "SlackChannelID"
    secret_pd_name = "PagerDutyChannelID"
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response_teams = client.get_secret_value(
            SecretId=secret_teams_name
        )
        get_secret_value_response_slack = client.get_secret_value(
            SecretId=secret_slacks_name
        )
        get_secret_value_response_pd = client.get_secret_value(
            SecretId=secret_pd_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response_teams:
            teams_channel_id = get_secret_value_response_teams['SecretString']
            print("Teams secret is" + teams_channel_id)

        if 'SecretString' in get_secret_value_response_slack:
            slack_channel_id = get_secret_value_response_slack['SecretString']
            print("Slack secret is" + slack_channel_id)

        if 'SecretString' in get_secret_value_response_pd:
            pd_channel_id = get_secret_value_response_pd['SecretString']
            print("Pager Duty secret is" + pd_channel_id)
        secrets = {
            "teams": teams_channel_id,
            "slack": slack_channel_id,
            "pdchannel": pd_channel_id}
    return secrets

def myconverter(json_object):
    """
    The __str__ method of the datetime object is called to return a string representation of the value.

    :param json_object: json object
    :type json_object: dict
    :return: string representation of the json object
    :rtype: str
    """
    if isinstance(json_object, datetime):
        return json_object.__str__()



def main(event, context):
    print("THANK YOU FOR CHOOSING AWS HEALTH CHECK!")
    # FOR TESTING
    with open('aws-status.json') as json_file:
        aws_events = json.load(json_file)
        for event in aws_events:
            print(event);
    send_test_alert(aws_events)


if __name__ == "__main__":
    main('', '')

