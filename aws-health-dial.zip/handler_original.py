import json
import boto3
from datetime import datetime,timedelta
import pytz
import requests
import time

# create a boto3 health client
health_client = boto3.client('health')
#ENVIRONMENT VARIABLES
#REST_API_EMAIL FOR PAGER DUTY
#

#Need to add this as a parameter to the CFN stack
REST_API_EMAIL="gmridula@amazon.com"
#Need to add this as a parameter to the CFN stack
#Slack channel for pagerduty exceptions
impact_dial_pd_fail_slack_channel = 'BSSGTQEF4' #impact-dial-pd-fail channel

def describe_events():
    """
    Returns information about events that meet the specified filter criteria. Events are returned in a summary
    form and do not include the detailed description, any additional metadata that depends on the event type,
    or any affected resources.

    :return: dictionary of events
    :rtype: dict
    """
    dt_minus_1_minute_pst = (datetime.now() - timedelta(minutes=1)).astimezone(pytz.timezone('US/Pacific'))
    # Need to add this as a parameter to the CFN stack
    regions = [
        'us-east-1',
        'us-east-2',
        'us-west-1',
        'us-west-2',
        'ca-central-1',
        'sa-east-1',
        'global'
    ]

    response = health_client.describe_events(
        filter={
            'regions': regions,
            'lastUpdatedTimes': [
                {
                    'from': dt_minus_1_minute_pst
                },
            ],
            'eventTypeCategories': [
               'issue'
            ]
        }
    )
    events = response.get('events', [])

    if 'nextToken' in response:
        next_token = response['nextToken']
        while next_token:
            response = health_client.describe_events(
                filter={
                    'regions': regions,
                    'lastUpdatedTimes': [
                        {
                            'from': dt_minus_1_minute_pst
                        },
                    ],
                    'eventTypeCategories': [
                        'issue'
                    ]
                },
                nextToken=next_token
            )
            # print(response)
            if response is not None:
                events.extend(response.get('events', []))

                try:
                    next_token = response['nextToken']
                except BaseException:
                    next_token = False
    return events


def myconverter(json_object):
    """
    The __str__ method of the datetime object is called to return a string representation of the value.

    :param json_object: json object
    :type json_object: dict
    :return: string representation of the json object
    :rtype: str
    """
    if isinstance(json_object, datetime):
        return json_object.__str__()


def describe_event_details(event_arn):
    """
    Returns detailed information about one or more specified AWS health event. Information includes standard event
    data (region, service, etc., as returned by DescribeEvents), a detailed event description,
    and possible additional metadata that depends upon the nature of the event.

    :param event_arn: Unique ARN identifier of the event.
    :type event_arn: str
    :return: a dictionary of standard event data
    :rtype: dict
    """
    response = health_client.describe_event_details(
        eventArns=[event_arn],
    )
    return response


def cleanup_time_for_slack(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time=datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')


def pagerduty_failed_slack_alert(event_details, pd_response):
    """
    Takes as input the event_details and the pd_response. An alert with the PagerDuty payload details
    and the PagerDuty failure are then sent to the impact_dial_pd_fail_slack_channel.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param pd_response: Response received from PagerDuty.
    :type pd_response: Response object
    """
    # alert team that the PD event creation failed
    message = (
        f"*ALERT: The following event failed to be sent to PagerDuty:*\n `{event_details}`\n\n"
        f"*The following {pd_response.status_code} response was received:*\n `{pd_response.json()}`")
    slack_data = {'text': message}
    response = requests.post(
        impact_dial_pd_fail_slack_channel, data=json.dumps(slack_data),
        headers={'Content-Type': 'application/json'}
    )


def create_pd_summary(event_details):
    if event_details['successfulSet'][0]['event']['region']=='global':
        summary=(
            f"AWS reported a global issue with the {event_details['successfulSet'][0]['event']['service']} service on "
            f"{cleanup_time_for_slack(event_details['successfulSet'][0]['event']['lastUpdatedTime'])} "
            f"[{event_details['successfulSet'][0]['event']['arn'][-9:]}]"
        )
    else:
        summary=(
            f"AWS reported an issue with the {event_details['successfulSet'][0]['event']['service']} service in "
            f"{event_details['successfulSet'][0]['event']['region']} on "
            f"{cleanup_time_for_slack(event_details['successfulSet'][0]['event']['lastUpdatedTime'])} "
            f"[{event_details['successfulSet'][0]['event']['arn'][-9:]}]"
        )
    return summary


def pagerduty_put_post(endpoint,message,request_type):
    headers={
        "Content-Type": "application/json",
        "Accept": "application/vnd.pagerduty+json;version=2",
        "From": REST_API_EMAIL,
        "Authorization": f"Token token={pagerduty_api_key}"
    }
    if request_type=="post":
        return requests.post(endpoint,headers=headers,data=message)
    elif request_type=="put":
        return requests.put(endpoint,headers=headers,data=message)


def resolve_pd_incident(event_details, incident_id, incident_number, alert_slack=True):
    """
    Takes as input the event_details.  This method acts as the driver for
    resolving an incident in PagerDuty and logging/alerting any necessary details.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param incident_id: unique ID for the PagerDuty incident
    :type incident_id: str
    :param incident_number: unique incident number for the PagerDuty incident
    :type incident_number: str
    """
    #update the notes with most recent updates, then close the incident
    update_pd_incident(event_details, incident_number)

    endpoint=f"https://api.pagerduty.com/incidents/{incident_id}"
    print(endpoint)

    message={
        "incident": {
            "type": "incident",
            "status": "resolved",
            "resolution": f"Resolution Note: {get_last_AWS_update(event_details)}"
        }
    }
    message=json.dumps(message)
    response=pagerduty_put_post(endpoint,message,"put")
    print(f"response.status_code: {response.status_code}")
    print(f"resolve incident response: {response.json()}")

    if response.status_code != 200:
        #send to SNS for retry
        payload={}
        payload['event_details']=event_details
        payload['api_type']='rest'
        payload['action_type']='resolve'
        payload['incident']={'incident_id':incident_id,'incident_number':incident_number}
        payload=json.dumps(payload)
        send_to_sqs_retry_queue(payload)

        # alert in Slack
        pagerduty_failed_slack_alert(event_details, response)
    else:
        if alert_slack:
            send_to_slack(event_details,event_type="resolve")


def create_pd_incident(event_details,alert_slack=True):
    """
    Takes as input the event_details and an alert_slack_flag.  This method acts as the driver for creating
    an incident in PagerDuty and logging/alerting any necessary details.

    :param event_details: Detailed information about a specific AWS health event
    :type event_details: dict
    :param alert_slack: flag that can be set to False to not send alert to slack (for the events opened/closed within
    the minute window)
    :type alert_slack: boolean
    :return pd_response: response from the pagerduty event creation call
    :rtype: requests response object
    """
    criticality=set_alert_criticality(event_details['successfulSet'][0]['event']['service'])
    if criticality:
        criticality="high"
    else:
        criticality="low"

    summary=create_pd_summary(event_details)

    endpoint="https://api.pagerduty.com/incidents"

    body=(f"arn: {event_details['successfulSet'][0]['event']['arn']}\n"
        f"service: {event_details['successfulSet'][0]['event']['service']}\n"
        f"eventTypeCode: {event_details['successfulSet'][0]['event']['eventTypeCode']}\n"
        f"eventTypeCategory: {event_details['successfulSet'][0]['event']['eventTypeCategory']}\n"
        f"region: {event_details['successfulSet'][0]['event']['region']}\n"
        f"startTime: {event_details['successfulSet'][0]['event']['startTime']}\n"
        f"lastUpdatedTime: {event_details['successfulSet'][0]['event']['lastUpdatedTime']}\n"
        f"statusCode: {event_details['successfulSet'][0]['event']['statusCode']}\n"
        f"update_from_aws: {event_details['successfulSet'][0]['eventDescription']['latestDescription']}\n"
    )
    message={
        "incident": {
            "type": "incident",
            "title": summary,
            "service": {
                "id": "PR8JG2G",
                "type": "service_reference"
            },
            "urgency": criticality,
            "incident_key": "",
            "body": {
                "type": "incident_body",
                "details": body
            }
        }
    }
    message=json.dumps(message)

    response=pagerduty_put_post(endpoint,message,"post")
    print(f"response.status_code: {response.status_code}")
    print(response.json())
    incident_number=response.json()['incident']['incident_number']
    incident_id=response.json()['incident']['id']

    # if not 201 response, alert in slack and send to SQS
    if response.status_code != 201:
        #send tp SQS
        payload={}
        payload['event_details']=event_details
        payload['api_type']='event'
        payload['action_type']='create'
        payload=json.dumps(payload)
        send_to_sqs_retry_queue(payload)
        # alert in Slack
        pagerduty_failed_slack_alert(event_details, response)
        return None,None,None
    else:
        if alert_slack:
            #updates notes with the AWS update message
            time.sleep(5)
            update_pd_incident(event_details,incident_number)
            time.sleep(4)
            send_to_slack(event_details,event_type="create")

    return response,incident_id,incident_number


def update_pd_incident(event_details, incident_number):
    """
    Takes as input the event_details and PD incident_number.  This method acts as the driver for updating
    an event in PagerDuty and logging/alerting any necessary details.

    :param event_details: Detailed information about a specific AWS health event
    :type event_details: dict
    :param incident_number: unique incident number for the PagerDuty incident
    :type incident_number: str
    """
    latest_update = get_last_AWS_update(event_details)
    print(latest_update)

    post_update = True
    notes = get_pagerduty_incident_notes(incident_number)
    for note in notes['notes']:
        if latest_update == note['content']:
            print(f"{note['content']}\n")
            post_update = False
            break

    if post_update:
        endpoint=f"https://api.pagerduty.com/incidents/{incident_number}/notes"
        print(endpoint)

        message = {
            "note": {
                "content": latest_update
            }
        }
        message=json.dumps(message)

        response=pagerduty_put_post(endpoint,message,"post")
        print(f"response.status_code: {response.status_code}")
        print(response.json())

        if response.status_code != 201:
            #send to SNS for retry
            payload={}
            payload['event_details']=event_details
            payload['api_type']='rest'
            payload['action_type']='update'
            payload['incident']={'incident_id':'N/A','incident_number':incident_number}
            payload=json.dumps(payload)
            send_to_sqs_retry_queue(payload)
            # alert in Slack
            pagerduty_failed_slack_alert(event_details, response.json())


def open_resolved_pd_incident(event_details):
    """
    Takes as input the event_details.  This method acts as the driver
    for creating an event in PagerDuty and logging/alerting any necessary details.  This will handle a couple of
    edge cases:
        1. This health checker is checking every minute.  If an alert is opened then closed during the one minute
        interval, this method will open a PagerDuty event for it with the details from AWS, log it in the
        aws_health_check DynamoDB table, then resolve (close) the event.
        2. If AWS updates an event AFTER it has been closed, we will send that update to PagerDuty.  Since the
        original event created for this alert is already closed, PagerDuty treats this as a new event.  So this method
        will open a PagerDuty event for it with the details from AWS, log it in the aws_health_check DynamoDB table,
        then resolve (close) the event.

    :param event_details: Detailed information about a specific AWS health event
    :type event_details: dict
    """
    # this means that the event was updated after it was closed...with
    # pagerduty, this is looked at as a new event.
    response,incident_id,incident_number=create_pd_incident(event_details, alert_slack=False)

    time.sleep(2)

    if response is not None:
        resolve_pd_incident(event_details,incident_id,incident_number, alert_slack=False)


def get_secrets():
    """
    This retrieves all necessary secrets from secrets manager and sets a few global variables.
    """
    global pagerduty_api_key, routing_key, slack
    secrets_manager = boto3.client('secretsmanager', region_name='us-east-1')

    # get slack token and instantiate the Slackest Class
    secret = secrets_manager.get_secret_value(SecretId='slack_token')
    slack=Slackest(json.loads(secret['SecretString'])['impact_dial_token'])

    # get the PagerDuty routing key and api_key
    secret = secrets_manager.get_secret_value(SecretId='pagerduty')
    routing_key = json.loads(secret['SecretString'])['routing_key']
    pagerduty_api_key=json.loads(secret['SecretString'])['pagerduty_api_key']


def get_pagerduty_incident_notes(id):
    url = f"https://api.pagerduty.com/incidents/{id}/notes"
    headers={
        "Accept": "application/vnd.pagerduty+json;version=2",
        "Authorization": f"Token token={pagerduty_api_key}"
    }
    response=requests.get(url,headers=headers)
    return response.json()


def get_pagerduty_incidents():
    """
    This retrieves all pagerduty incidents from the last 30 days

    :return: all incidents from 30 days prior (triggered, acknowledged and resolved)
    :rtype: dict
    """
    #get date 29 days ago for api request filter (for some reason...anything greater than 29 days would not work correctly)...
    since_date = datetime.now() - timedelta(days=29)
    since_date=since_date.strftime('%Y-%m-%d')

    #payload variables
    statuses = ['triggered','resolved','acknowledged']
    team_ids = ['PQJHF61']
    time_zone = 'UTC'
    offset = 0

    incidents=()

    headers={
        "Accept": "application/vnd.pagerduty+json;version=2",
        "Authorization": f"Token token={pagerduty_api_key}"
    }

    url = "https://api.pagerduty.com/incidents"
    payload={
        'since':since_date,
        'offset':offset,
        'team_ids[]':team_ids,
        'time_zone':time_zone,
        'statuses[]':statuses
    }
    response=requests.get(url,headers=headers,params=payload)

    for incident in response.json()['incidents']:
        incidents+=incident,

    while response.json()['more']:
        offset+=25
        payload={
            'since':since_date,
            'offset':offset,
            'team_ids[]':team_ids,
            'time_zone':time_zone,
            'statuses[]':statuses
        }
        response=requests.get(url,headers=headers,params=payload)
        if response is not None:
            for incident in response.json()['incidents']:
                incidents+=incident,

    return incidents


def incident_check(incidents,arn_id):
    """
    Takes as input all incidents from PagerDuty from the last 30 days and looks to see if there is an incident
    for the unique event being alerted on (using the numbers appended to the AWS event ARN)

    :param incidents: all incidents from 30 days prior (triggered, acknowledged and resolved)
    :type incidents: dict
    :param arn_id: the id that is appended at the end of the AWS event arn
    :type arn_id: str
    :return: a boolean value indicating if the incident exists.  if it does, the incident is also returned,
            otherwise None is returned
    :rtype: boolean, dict
    """
    for incident in incidents:
        if arn_id in incident['title']:
            print(f"{incident['id']} found for {arn_id}")
            return True,incident
    return False,None


def send_to_sqs_retry_queue(payload):
    """
    Takes as input the failed payload and sends it to SQS.

    :param payload: includes the event_details, api_type and action_type
    :type payload: dict
    """
    client = boto3.client('sqs')
    response = client.send_message(
        QueueUrl='https://sqs.us-east-1.amazonaws.com/182730369717/pagerduty_api_failure',
        MessageBody=payload,
        DelaySeconds=30,
        MessageAttributes={
            'Name': {
                'StringValue': 'Failed PagerDuty payload',
                'DataType': 'String'
            }
        }
    )
    print(response)


def get_last_AWS_update(event_details):
    """
    Takes as input the event_details and returns the last update from AWS (instead of the entire timeline)

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :return: the last update message from AWS
    :rtype: str
    """
    aws_message=event_details['successfulSet'][0]['eventDescription']['latestDescription']
    aws_messages_list=aws_message.split("\n\n")
    aws_resolve_message=aws_messages_list[len(aws_messages_list)-1]
    return aws_resolve_message


def send_to_slack(event_details, event_type):
    """
    Takes as input the event_details and event_type. An alert is sent to notify the
    our AWS slack channels of new or resolved health events from the AWS health check.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param event_type: type of event - i.e. incident creation/resolution
    :type event_type: str
    """
    summary=""
    message=""

    if event_type == "create":
        summary+=(
            f"[NEW] AWS reported an issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {event_details['successfulSet'][0]['eventDescription']['latestDescription']}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    elif event_type == "resolve":
        summary+=(
            f"[RESOLVED] The AWS issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*End Time:* {cleanup_time_for_slack(event_details['successfulSet'][0]['event']['endTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {get_last_AWS_update(event_details)}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are still experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    #FOR TESTING - #josh-testing-2 channel
    # slack.chat.post_message("GDGP354K1", text=message)

    alert_channel_ids = [
        "C2K8X7Y2C", #aws-support
        "C1E2RHDPE", #aws-working-group
        "C4Q5KE67Q", #exton-aws-support
        "CADUUD716", #aws-account-owners
        "C6F6DKV42", #cms-aws-working-group
        "CJJRCDJMR" #aws-status
    ]

    #ALERT ALL CHANNELS
    for id in alert_channel_ids:
        slack.chat.post_message(id, text=message)
        time.sleep(3)

    #alert EOC
    alert_eoc(event_details, event_type)


def alert_eoc( event_details, event_type):
    """
    Takes as input the event_details. The EOC will be alerted based on the criticality
    of the event.  The EOC alert message will be different than the message to our AWS channels.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    """
    eoc_slack_message=""
    critical_alert=set_alert_criticality(event_details['successfulSet'][0]['event']['service'])

    if event_type == "create":
        if critical_alert:
            email_subject=(
                f"[NEW] FYI - AWS reported a CRITICAL issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service "
                f"in the {event_details['successfulSet'][0]['event']['region'].upper()} region.\n"
            )
            eoc_slack_message=f"{email_subject}\nFor updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            #send email to the EOC
            email_eoc(email_subject,event_details)
        else:
            eoc_slack_message=(
                f"[NEW] FYI - AWS reported an issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service "
                f"in the {event_details['successfulSet'][0]['event']['region'].upper()} region.\n"
                f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            )
    elif event_type=="resolve":
        if critical_alert:
            email_subject=(
                f"[RESOLVED] FYI - The CRITICAL issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service "
                f"in the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved.\n"
            )
            eoc_slack_message=f"{email_subject}\nFor updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"

            #send email to the EOC
            email_eoc(email_subject,event_details)
        else:
            eoc_slack_message=(
                f"[RESOLVED] FYI - The issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service "
                f"in the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved.\n"
                f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            )

    #post eoc_slack_message in #eoc slack channel
    slack.chat.post_message("C37E3M0EQ", text=eoc_slack_message) #eoc slack channel


def set_alert_criticality(service):
    """
    Takes as input the service for the AWS health event.  True is returned if the service exists in the list of
    critical_alert_services; otherwise False is returned.

    :param service: Service name
    :type service: str
    :return: True if CRITICAL alert; otherwise FALSE
    :rtype: bool
    """
    critical_alert_services=[
        "IAM","S3","LAMBDA","EC2","RDS","APIGATEWAY","KMS","ECS","ELASTICBEANSTALK","EKS","SNS","SQS","ECR","EBS",
        "ELASTICFILESYSTEM","AURORA","ELASTICACHE","REDSHIFT","CLOUDFRONT","WAF","ACM","DIRECTCONNECT","ELASTICLOADBALANCING",
        "VPC","VPCE_PRIVATELINK","SECRETSMANAGER","ROUTE53","ROUTE53DOMAINREGISTRATION","ROUTE53PRIVATEDNS","ROUTE53RESOLVER",
        "NATGATEWAY","DYNAMODB"
    ]
    if service in critical_alert_services:
        return True
    else:
        return False


def email_eoc(email_subject,event_details):
    # These addresses must be verified with Amazon SES.
    SENDER = "gmridula@amazon.com"
    RECIPIENT = ['gmridula@amazon.com']
    # RECIPIENT = "gmridula@amazon.com" #for testing
    AWS_REGION = "us-east-1"
    SUBJECT = email_subject

    BODY_HTML = f"""
        <html>
            <body>
                <h>Greetings!</h><br>
                <p>Here are the details from the AWS Health Alert:<br>
                <b>Event ARN:</b> {event_details['successfulSet'][0]['event']['arn']}<br>
                <b>Service:</b> {event_details['successfulSet'][0]['event']['service']}<br>
                <b>Region:</b> {event_details['successfulSet'][0]['event']['region']}<br>
                <b>Status:</b> {event_details['successfulSet'][0]['event']['statusCode']}<br>
                <b>Message from AWS:</b> {event_details['successfulSet'][0]['eventDescription']['latestDescription']}<br><br>
                For updates, please visit the <a href=https://status.aws.amazon.com>AWS Service Health Dashboard</a><br><br>
                Thanks, <br>Cloud Bizops
                </p>
            </body>
        </html>
    """

    client = boto3.client('ses',region_name=AWS_REGION)
    response = client.send_email(
        Source=SENDER,
        Destination={
            'ToAddresses': RECIPIENT
        },
        Message={
            'Body': {
                'Html': {
                    'Data': BODY_HTML
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': SUBJECT,
            },
        },
    )
    print(response)


def main(event, context):
    """
    The main method that drives the workflow.

    :param event: Event source
    :type event: dict
    :param context: Provides methods and properties that provide information about the invocation, function, and
    execution environment.
    :type context: Context object
    """
    print(event)
    if 'Records' not in event:
        aws_events=describe_events()
        #converting
        aws_events=json.dumps(aws_events, default=myconverter)
        #parsing
        aws_events=json.loads(aws_events)

        #FOR TESTING
        # with open('aws-status.json') as f:
        #     aws_events = json.load(f)

        if len(aws_events) > 0: #if there are new event(s) from AWS
            #get slack token and PD keys from secrets mgr and create global variables
            get_secrets()

            #get any open incidents from PagerDuty
            incidents=get_pagerduty_incidents()
            print(incidents)

            #reverse the list of events so that the oldest updates are processed first
            aws_events.reverse()
            for event in aws_events:
                event_arn = event['arn']
                status_code = event['statusCode']

                #get event details
                event_details = json.dumps(describe_event_details(event_arn), default=myconverter)
                event_details = json.loads(event_details)

                #FOR TESTING
                # with open('get_event_details.json') as f:
                #     event_details = json.load(f)

                print(status_code)
                print(event_details)

                incident_exists,incident=incident_check(incidents,event_arn[-9:])

                if status_code == 'closed':

                    #if incident exists in PagerDuty for the event being triggered from AWS
                    if incident_exists:
                        if incident['status'] != 'resolved':
                            # resolve the open event in PD
                            resolve_pd_incident(event_details, incident['id'], incident['incident_number'])
                        else:
                            # this means that AWS provided updates after the event was
                            # closed...update the incident notes with most recent updates
                            update_pd_incident(event_details, incident['incident_number'])

                    else:
                        # this means that the event was opened and closed during the window (likely an edge case since
                        # we will be checking every minute).
                        # per boatright: send it to PagerDuty with the last notes
                        open_resolved_pd_incident(event_details)

                elif status_code == 'open':

                    if incident_exists: #update the existing event (add update from AWS to the incident notes)
                        update_pd_incident(event_details, incident['incident_number'])
                    else: #create a new incident
                        create_pd_incident(event_details)

                elif status_code == 'upcoming':
                    # what do we do with upcoming alerts?
                    pass
    else:
        get_secrets()

        print(event)
        event=json.loads(event['Records'][0]['body'])
        event_details=event['event_details']
        action_type=event['action_type']
        api_type=event['api_type']

        print(f"{event_details}\n")
        print(f"{action_type}\n")
        print(f"{api_type}\n")

        if api_type == "event":
            create_pd_incident(event_details)
        elif api_type == "rest":
            incident_id=event['incident']['incident_id']
            incident_number=event['incident']['incident_number']
            print(incident_id)
            print(incident_number)

            if action_type=='update':
                update_pd_incident(event_details, incident_number)
            elif action_type=='resolve':
                resolve_pd_incident(event_details, incident_id, incident_number)