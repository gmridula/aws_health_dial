import json
import boto3
from datetime import datetime, timedelta
import pytz
import pymsteams
import requests
from botocore.exceptions import ClientError
import os
import time

def getmessageforslack(event_details, event_type):
    message = ""
    summary = ""
    if event_type == "create":
        summary+=(
            f"[NEW] AWS reported an issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {event_details['successfulSet'][0]['eventDescription']['latestDescription']}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    elif event_type == "resolve":
        summary+=(
            f"[RESOLVED] The AWS issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved."
        )
        message = (
            f"--------------\n*{summary}*\n"
            f">*Event ARN:* {event_details['successfulSet'][0]['event']['arn']}\n"
            f">*Service:* {event_details['successfulSet'][0]['event']['service']}\n"
            f">*Region:* {event_details['successfulSet'][0]['event']['region']}\n"
            f">*Start Time:* {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f">*End Time:* {cleanup_time(event_details['successfulSet'][0]['event']['endTime'])}\n"
            f">*Status:* {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f">*Message from AWS:* {get_last_AWS_update(event_details)}\n"
            f"For updates, please visit the <https://status.aws.amazon.com/|AWS Service Health Dashboard>.\n"
            f"*If you are still experiencing issues related to this event, please open an AWS Support case within your account.*\n"
        )

    return message

def getmessage(event_details, event_type):
    message = ""
    summary = ""
    if event_type == "create":
        summary+=(
            f"[NEW] AWS reported an issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region."
        )
        message = (
            f"\n{summary}\n"
            f"Event ARN: {event_details['successfulSet'][0]['event']['arn']}\n"
            f"Service: {event_details['successfulSet'][0]['event']['service']}\n"
            f"Region: {event_details['successfulSet'][0]['event']['region']}\n"
            f"Start Time: {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f"Status: {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f"Message from AWS: {event_details['successfulSet'][0]['eventDescription']['latestDescription']}\n"
            f"If you are experiencing issues related to this event, please open an AWS Support case within your account.\n"
        )

    elif event_type == "resolve":
        summary+=(
            f"[RESOLVED] The AWS issue with the {event_details['successfulSet'][0]['event']['service'].upper()} service in "
            f"the {event_details['successfulSet'][0]['event']['region'].upper()} region is now resolved."
        )
        message = (
            f"\n{summary}\n"
            f"Event ARN: {event_details['successfulSet'][0]['event']['arn']}\n"
            f"Service: {event_details['successfulSet'][0]['event']['service']}\n"
            f"Region: {event_details['successfulSet'][0]['event']['region']}\n"
            f"Start Time: {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}\n"
            f"End Time: {cleanup_time(event_details['successfulSet'][0]['event']['endTime'])}\n"
            f"Status: {event_details['successfulSet'][0]['event']['statusCode']}\n"
            f"Message from AWS: {get_last_AWS_update(event_details)}\n"
            f"If you are still experiencing issues related to this event, please open an AWS Support case within your account.\n"
        )

    return message

def getmessageforemail(event_details, event_type):
    if event_type == "create":
        BODY_HTML = f"""
        <html>
            <body>
                <h>Greetings!</h><br>
                <p>There is an AWS incident that is in effect which may likely impact your resources. Here are the details (triggered from AWS Health Dial):<br>
                <b>Event ARN:</b> {event_details['successfulSet'][0]['event']['arn']}<br>
                <b>Service:</b> {event_details['successfulSet'][0]['event']['service']}<br>
                <b>Region:</b> {event_details['successfulSet'][0]['event']['region']}<br>
                <b>Status:</b> {event_details['successfulSet'][0]['event']['statusCode']}<br>
                <b>StartTime:</b> {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}<br>
                For updates, please visit the <a href=https://status.aws.amazon.com>AWS Service Health Dashboard</a><br><br>
                Thanks, <br>Cloud Bizops
                </p>
            </body>
        </html>
    """
    else:
        BODY_HTML = f"""
                    <html>
                        <body>
                            <h>Hello Everyone!</h><br>
                            <p>UPDATE on the AWS incident:<br>
                            <b>Event ARN:</b> {event_details['successfulSet'][0]['event']['arn']}<br>
                            <b>Service:</b> {event_details['successfulSet'][0]['event']['service']}<br>
                            <b>Region:</b> {event_details['successfulSet'][0]['event']['region']}<br>
                            <b>Status:</b> {event_details['successfulSet'][0]['event']['statusCode']}<br>
                            <b>StartTime:</b> {cleanup_time(event_details['successfulSet'][0]['event']['startTime'])}<br>
                            <b>EndTime:</b> {cleanup_time(event_details['successfulSet'][0]['event']['endTime'])}
                            If you are impacted, please open an AWS Support case from the impacted account(s) and reply back to this email by describing the impact this is having on your environments.
                            <br><br>
                            Thanks, <br>AWS TAM Team
                            </p>
                        </body>
                    </html>
                """
    return BODY_HTML



def cleanup_time(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')

def get_last_AWS_update(event_details):
    """
    Takes as input the event_details and returns the last update from AWS (instead of the entire timeline)

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :return: the last update message from AWS
    :rtype: str
    """
    aws_message = event_details['successfulSet'][0]['eventDescription']['latestDescription']
    aws_messages_list = aws_message.split("\n\n")
    aws_resolve_message = aws_messages_list[len(aws_messages_list) - 1]
    return aws_resolve_message

def format_date(event_time):
    """
    Takes as input a datetime string as received from the AWS event_detail call.  It converts this string to a
    datetime object, changes the timezone to EST and then formats it into a readable string to display in Slack.

    :param event_time: datetime string
    :type event_time: str
    :return: A formatted string that includes the month, date, year and 12-hour time.
    :rtype: str
    """
    event_time = datetime.strptime(event_time[:16], '%Y-%m-%d %H:%M')
    return event_time.astimezone(pytz.timezone('US/Eastern')).strftime('%B %d, %Y at %I:%M %p')
