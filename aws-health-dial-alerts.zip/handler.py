import json
import boto3
from datetime import datetime, timedelta
import pytz
import pymsteams
import requests
from botocore.exceptions import ClientError
import os
import time
from messagegenerator import getmessageforslack, getmessageforemail , getmessage

# create a boto3 health client
health_client = boto3.client('health')


def send_alert(event_details, event_type):
    """
    Takes as input the event_details and event_type. An alert is sent to notify the
    our AWS slack channels of new or resolved health events from the AWS health check.

    :param event_details: Detailed information about a specific AWS health event.
    :type event_details: dict
    :param event_type: type of event - i.e. incident creation/resolution
    :type event_type: str
    """

    slack_url = get_secrets()["slack"]
    teams_url = get_secrets()["teams"]
    chime_url = get_secrets()["chime"]
    SENDER = os.environ['FROM_EMAIL']
    RECIPIENT = os.environ['TO_EMAIL'].split(",")
    #FOR TESTING
    #slack_url="https://hooks.slack.com/services/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"
    #teams_url = "https://outlook.office.com/webhook/af0a6d78-8efa-4bb5-a261-0a104c945fb4@7c7fea3f-e205-448e-b10a-701c54916e39/IncomingWebhook/3cd473708fbd458cb2b02472a0913237/ca7ecff1-83f2-4743-9a3f-4fa8ea13eddf"

    if slack_url != "None":
        send_to_slack(getmessageforslack(event_details, event_type), slack_url)
    if teams_url != "None":
        #send_to_teams(getmessageforteams(event_details, event_type), teams_url)
        send_to_teams(getmessage(event_details, event_type), teams_url)
    if SENDER != "None" and RECIPIENT != "None":
        send_email(event_details, event_type)
    if chime_url != "None":
        send_to_chime(getmessage(event_details, event_type), chime_url)

def send_to_slack(message, webhookurl):
    slack_data = {'text': message}
    response = requests.post(
        webhookurl, data=json.dumps(slack_data),
        headers={'Content-Type': 'application/json'}
    )
    if response.status_code != 200:
        raise ValueError(
            'Request to slack returned an error %s, the response is:\n%s'
            % (response.status_code, response.text)
        )

def send_to_chime(message, webhookurl):

    chime_message="-----AWS HEALTH ALERT-----"+(message)
    response = requests.post(url=webhookurl,json={"Content": (chime_message)})
    if response.status_code != 200:
        raise ValueError(
            'Request to chime returned an error %s, the response is:\n%s'
            % (response.status_code, response.text)
        )

def send_to_teams(message, webhookurl):
    # create the connectorcard object with the Microsoft Webhook URL
    myTeamsMessage = pymsteams.connectorcard(webhookurl)
    myMessageSection = pymsteams.cardsection()
    # Add title
    messagesplit=message.splitlines()
    i = 2
    while i <= len(messagesplit)-1:
        if(":" in messagesplit[i]):
         myMessageSection.addFact(messagesplit[i].split(":",1)[0],messagesplit[i].split(":",1)[1])
        else:
             myMessageSection.addFact("", messagesplit[i])
        i+=1;
    myTeamsMessage.addSection(myMessageSection)
    myTeamsMessage.title("AWS HEALTH ALERT")
    myTeamsMessage.addLinkButton("For more Updates Please visit AWS Service Health Dashboard", "https://status.aws.amazon.com/")
    # Add text to the message.
    myTeamsMessage.text(messagesplit[1])
    # send the message.
    myTeamsMessage.send()


def send_email(event_details, eventType):
    SENDER = os.environ['FROM_EMAIL']
    RECIPIENT = os.environ['TO_EMAIL'].split(",")
    # RECIPIENT += os.environ['FROM_EMAIL']
    # RECIPIENT = "gmridula@amazon.com" #for testing
    AWS_REGION = "us-east-1"
    SUBJECT = os.environ['EMAIL_SUBJECT']
    BODY_HTML = getmessageforemail(event_details, eventType)
    client = boto3.client('ses',region_name=AWS_REGION)
    response = client.send_email(
        Source=SENDER,
        Destination={
            'ToAddresses': RECIPIENT
        },
        Message={
            'Body': {
                'Html': {
                    'Data': BODY_HTML
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': SUBJECT,
            },
        },
    )
    print(response)




def get_secrets():
    secret_teams_name = "MicrosoftChannelID"
    secret_slacks_name = "SlackChannelID"
    secret_pd_name = "PagerDutyChannelID"
    secret_chime_name = "ChimeChannelID"
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response_teams = client.get_secret_value(
            SecretId=secret_teams_name
        )
        get_secret_value_response_slack = client.get_secret_value(
            SecretId=secret_slacks_name
        )
        get_secret_value_response_pd = client.get_secret_value(
            SecretId=secret_pd_name
        )
        get_secret_value_response_chime = client.get_secret_value(
            SecretId=secret_chime_name
        )

    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response_teams:
            teams_channel_id = get_secret_value_response_teams['SecretString']
            print("Teams secret is" + teams_channel_id)

        if 'SecretString' in get_secret_value_response_slack:
            slack_channel_id = get_secret_value_response_slack['SecretString']
            print("Slack secret is" + slack_channel_id)

        if 'SecretString' in get_secret_value_response_pd:
            pd_channel_id = get_secret_value_response_pd['SecretString']
            print("Pager Duty secret is" + pd_channel_id)

        if 'SecretString' in get_secret_value_response_chime:
            chime_channel_id = get_secret_value_response_chime['SecretString']
            print("Chime secret is" + chime_channel_id)

        secrets = {
            "teams": teams_channel_id,
            "slack": slack_channel_id,
            "pdchannel": pd_channel_id,
            "chime": chime_channel_id}
    return secrets

def describe_events():
    """
    Returns information about events that meet the specified filter criteria. Events are returned in a summary
    form and do not include the detailed description, any additional metadata that depends on the event type,
    or any affected resources.

    :return: dictionary of events
    :rtype: dict
    """
    dt_frequency_pst = (datetime.now() - timedelta(minutes=1)).astimezone(pytz.timezone('US/Pacific'))
    # Need to add this as a parameter to the CFN stack
    delimiter = "|"
    regionlist = os.environ['REGIONS_LIST']
    #regionlist = "us-east-1|us-east-2|global"
    if not regionlist:
        # Default covers for US regions
        regions = [
            'us-east-1',
            'us-east-2',
            'us-west-1',
            'us-west-2',
            'global'
        ]
    else:
        regions = regionlist.split("|")
    for aws_region in regions:
        print("User selected regions:" + aws_region)
    response = health_client.describe_events(
        filter={
            'regions': regions,
            #Comment this for testing - START
            'lastUpdatedTimes': [
                {
                    'from': dt_frequency_pst
                },
            ],
            # Comment this for testing - END
            'eventTypeCategories': [
                'issue'
            ]
        }
    )
    print(response)
    events = response.get('events', [])
    print(events)

    if 'nextToken' in response:
        next_token = response['nextToken']
        while next_token:
            response = health_client.describe_events(
                filter={
                    'regions': regions,
                    'lastUpdatedTimes': [
                        {
                            'from': dt_frequency_pst
                        },
                    ],
                    'eventTypeCategories': [
                        'issue'
                    ]
                },
                nextToken=next_token
            )
            print(response)
            if response is not None:
                events.extend(response.get('events', []))

                try:
                    next_token = response['nextToken']
                except BaseException:
                    next_token = False
    return events


def myconverter(json_object):
    """
    The __str__ method of the datetime object is called to return a string representation of the value.

    :param json_object: json object
    :type json_object: dict
    :return: string representation of the json object
    :rtype: str
    """
    if isinstance(json_object, datetime):
        return json_object.__str__()

def describe_event_details(event_arn):
    """
    Returns detailed information about one or more specified AWS health event. Information includes standard event
    data (region, service, etc., as returned by DescribeEvents), a detailed event description,
    and possible additional metadata that depends upon the nature of the event.

    :param event_arn: Unique ARN identifier of the event.
    :type event_arn: str
    :return: a dictionary of standard event data
    :rtype: dict
    """
    response = health_client.describe_event_details(
        eventArns=[event_arn],
    )
    return response


def main(event, context):
    print("THANK YOU FOR CHOOSING AWS HEALTH CHECK!")
    # Keep polling the HEALTH API
    print(event)
    if 'Records' not in event:
        aws_events = describe_events()
        # converting
        aws_events = json.dumps(aws_events, default=myconverter)
        # parsing
        aws_events = json.loads(aws_events)
        print(aws_events)
        if len(aws_events) > 0: #if there are new event(s) from AWS
            #get slack token and PD keys from secrets mgr and create global variables
            #get_secrets()
            aws_events.reverse()
            for event in aws_events:
                event_arn = event['arn']
                status_code = event['statusCode']

                #get event details
                event_details = json.dumps(describe_event_details(event_arn), default=myconverter)
                event_details = json.loads(event_details)
                if status_code != "closed":
                    send_alert(event_details, event_type="create")
                else:
                    send_alert(event_details, event_type="resolve")


if __name__ == "__main__":
    main('', '')

